using System;

namespace RecipeScaler
{
    class Recipe                               // THIS CLASS ENABLES THE USER TO INSERT INFORMATION RELATED TO THE RECIPE.
    {
        private string[] ingredients;
        private double[] quantities;
        private string[] units;
        private string[] steps;

        public Recipe()                        // THIS METHOD RECORDS THE INGREDIENTS.
        {
            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            ingredients = new string[numIngredients];
            quantities = new double[numIngredients];
            units = new string[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                ingredients[i] = Console.ReadLine();

                Console.Write($"Enter ingredient {i + 1} quantity: ");
                quantities[i] = double.Parse(Console.ReadLine());

                Console.Write($"Enter ingredient {i + 1} unit of measurement: ");
                units[i] = Console.ReadLine();
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            steps = new string[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                steps[i] = Console.ReadLine();
            }
        }

        public void DisplayRecipe()                           // THIS METHOD ENABLES THE OUTPUT OF THE RECIPE TO BE DISPLAYED TO THE USER.
        {
            Console.WriteLine("Ingredients:");

            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"{quantities[i]} {units[i]} {ingredients[i]}");
            }

            Console.WriteLine("\nSteps:");

            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= factor;
            }
        }

        public void ResetQuantities()                                   // ENABLES QUANTITIES TO BE RESET TO THE ORIGINAL VALUES.
        {
            // TODO: implement
        }

        public void ClearRecipe()                                       // THIS METHOD ENABLES USERS TO CLEAR ALL DATA A TO ENTER A NEW RECIPE.
        {
            ingredients = null;
            quantities = null;
            units = null;
            steps = null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();                                                  // IN THIS METHOD NEW RECIPES ARE DISPLAYED AND STORED GIVEN THE OPTIONS TO RESET AND CLEAR THEM AS WELL.

            while (true)
            {
                Console.WriteLine("\nEnter an option:");
                Console.WriteLine("1. Display recipe");
                Console.WriteLine("2. Scale recipe");
                Console.WriteLine("3. Reset quantities");
                Console.WriteLine("4. Clear recipe");
                Console.WriteLine("5. Quit");

                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        recipe.DisplayRecipe();
                        break;

                    case 2:
                        Console.Write("Enter scale factor: ");
                        double factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                        break;

                    case 3:
                        recipe.ResetQuantities();
                        break;

                    case 4:
                        recipe.ClearRecipe();
                        recipe = new Recipe();
                        break;

                    case 5:
                        return;

                    default:
                        Console.WriteLine("Invalid option");
                        break;
                }
            }
        }
    }
}